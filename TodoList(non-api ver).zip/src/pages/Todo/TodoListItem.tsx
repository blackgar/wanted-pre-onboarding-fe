import { useState } from "react";
import { ITodo } from "./Todo";

interface ITodoItem {
  task: ITodo;
  onRemove: Function;
  onEdit: Function;
  onTodoChange: Function;
}

function Item({ task, onRemove, onEdit, onTodoChange }: ITodoItem) {
  const { todoId, todo, completed, active } = task;
  const [newTitle, setNewTitle] = useState("");
  return (
    <div>
      <h3>{todoId}번째 할 일</h3>
      <h4>{todo}</h4>
      {active ? (
        <div>
          <input
            onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
              setNewTitle(e.target.value)
            }
          />
          <button onClick={() => onTodoChange(todoId, newTitle)}>
            수정완료
          </button>
        </div>
      ) : (
        <button onClick={() => onEdit(todoId)}>수정</button>
      )}
      <button onClick={() => onRemove(todoId)}>삭제</button>
    </div>
  );
}

export default Item;
