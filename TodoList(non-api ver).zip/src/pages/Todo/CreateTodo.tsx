interface ITodo {
  title: string;
  onChange: React.ChangeEventHandler<HTMLInputElement>;
  onCreate: React.FormEventHandler<HTMLFormElement>;
}
function CreateTodo({ title, onChange, onCreate }: ITodo) {
  return (
    <div>
      <form onSubmit={onCreate}>
        <input type="text" value={title} onChange={onChange} />
        <button>등록</button>
      </form>
    </div>
  );
}

export default CreateTodo;
