import { ITodo } from "./Todo";
import Item from "./TodoListItem";
interface ITodoList {
  todos: ITodo[];
  onRemove: Function;
  onEdit: Function;
  onTodoChange: Function;
}

function TodoList({ todos, onRemove, onEdit, onTodoChange }: ITodoList) {
  return (
    <div>
      <>
        {todos ? (
          todos.map((v, idx) => (
            <Item
              key={idx}
              task={v}
              onRemove={onRemove}
              onEdit={onEdit}
              onTodoChange={onTodoChange}
            />
          ))
        ) : (
          <div>할 일을 등록해주세요</div>
        )}
      </>
    </div>
  );
}

export default TodoList;
