import { userInfo } from "os";
import { MutableRefObject, useEffect, useRef, useState } from "react";
import Swal from "sweetalert2";
import CreateTodo from "./CreateTodo";
import TodoList from "./TodoList";

export interface ITodo {
  todoId: number;
  todo: string;
  completed: boolean;
  active: boolean;
}
function Todo() {
  const token = localStorage.getItem("accessToken");
  const todoId = useRef(1);
  const [task, setTask] = useState({
    todo: "",
    completed: false,
    active: false,
  });
  const [todos, setTodos] = useState<ITodo[]>();
  const { todo, completed, active } = task;
  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTask({ todo: e.target.value, completed: false, active: false });
  };
  const onCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log(`Bearer ${token}`);
    fetch(`${process.env.REACT_APP_BASE_URL}todos`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-type": "application/json",
      },
      body: JSON.stringify({ todo: task.todo }),
    })
      .then((res) => res.json())
      .then((res) => console.log(res));
    if (todos) {
      const task = {
        todoId: todoId.current,
        todo,
        completed,
        active,
      };
      setTodos([...todos, task]);
    } else {
      const task = {
        todoId: todoId.current,
        todo,
        completed,
        active,
      };
      setTodos([task]);
    }
    setTask({ todo: "", completed: false, active: false });
    todoId.current += 1;
  };

  const onEdit = (taskId: number) => {
    setTodos(
      todos?.map((task) =>
        task.todoId === taskId ? { ...task, active: !task.active } : task
      )
    );
  };

  const onTodoChange = (taskId: number, content: string) => {
    Swal.fire({
      title: "수정요청",
      text: "할 일을 수정하시겠습니까?",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "확인",
      cancelButtonText: "취소",
    }).then((res) => {
      if (res.isConfirmed) {
        // setTodos(
        //   todos?.map((task) =>
        //     task.todoId === taskId
        //       ? { ...task, todo: content, active: !task.active }
        //       : task
        //   )
        // );
        fetch(`${process.env.REACT_APP_BASE_URL}todos`, {
          method: "POST",
          headers: {
            Authorization: "Bearer " + `${token}`,
            "Content-type": "application/json",
          },
          body: JSON.stringify({ todo: task.todo }),
        })
          .then((res) => res.json())
          .then((res) => console.log(res));
        Swal.fire("수정완료", "할 일을 수정했습니다.", "success");
      }
    });
  };

  const onRemove = (taskId: number) => {
    Swal.fire({
      title: "삭제요청",
      text: "할 일을 삭제하시겠습니까?",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#d33",
      cancelButtonColor: "#3085d6",
      confirmButtonText: "확인",
      cancelButtonText: "취소",
    }).then((res) => {
      if (res.isConfirmed) {
        setTodos(todos?.filter((task, idx) => task.todoId !== taskId));
        Swal.fire("삭제완료", "할 일을 삭제했습니다.", "warning");
      }
    });
  };

  useEffect(() => {
    console.log(todos);
  }, [todos]);

  return (
    <>
      <CreateTodo title={todo} onChange={onChange} onCreate={onCreate} />
      <TodoList
        todos={todos!}
        onRemove={onRemove}
        onEdit={onEdit}
        onTodoChange={onTodoChange}
      />
    </>
  );
}

export default Todo;
