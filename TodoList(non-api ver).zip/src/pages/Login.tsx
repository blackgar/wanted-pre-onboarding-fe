import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import Signup from "./Signup";

function Login() {
  const [openModal, setOpenModal] = useState(false);
  const [email, setEmail] = useState("");
  const [isEmailValid, setIsEmailValid] = useState(false);
  const [password, setPassword] = useState("");
  const [isPasswordValid, setIsPasswordValid] = useState(false);

  const onClick = () => {
    setOpenModal(true);
  };

  const closeModal = () => {
    setOpenModal(false);
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = { email, password };
    fetch(`${process.env.REACT_APP_BASE_URL}auth/signin`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((res) => res.json())
      .then((res) => {
        localStorage.setItem("accessToken", res.access_token);
      })
      .then((res) => window.location.reload())
      // .then((res) => navigate("/todo"))
      .catch((error) => console.log(error));
  };
  // 추가로 validation 적용하기
  const onChangeEmail = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    const emailRegex = /@/;
    if (emailRegex.test(e.target.value)) {
      setIsEmailValid(true);
    } else {
      setIsEmailValid(false);
    }
  };

  const onChangePassword = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
    if (e.target.value.length >= 8) {
      setIsPasswordValid(true);
    } else {
      setIsPasswordValid(false);
    }
  };
  console.log(email, password);
  return (
    <div>
      <form onSubmit={onSubmit}>
        <input type="text" onChange={onChangeEmail} />
        <input type="text" onChange={onChangePassword} />
        {isPasswordValid && isEmailValid && <button>Login</button>}
      </form>
      <div>
        <span>만약 계정이 없으시다면</span>
        <Link to="/" onClick={onClick}>
          회원가입
        </Link>
        <span>해주세요</span>
        {/* <button>Singup</button> */}
        {openModal && <Signup open={openModal} onClose={closeModal} />}
      </div>
    </div>
  );
}

export default Login;
