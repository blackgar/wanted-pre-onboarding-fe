import { useState } from "react";
import ReactModal from "react-modal";
import Swal from "sweetalert2";

interface IModal {
  open: boolean;
  onClose: Function;
}

function Signup({ open, onClose }: IModal) {
  const [modalIsOpen, setModalIsOpen] = useState(open);
  const [email, setEmail] = useState("");
  const [isEmailValid, setIsEmailValid] = useState(false);
  const [password, setPassword] = useState("");
  const [isPasswordValid, setIsPasswordValid] = useState(false);

  const modalStyle = {
    content: {
      top: "50%",
      left: "50%",
      right: "auto",
      bottom: "auto",
      marginRight: "-50%",
      transform: "translate(-50%, -50%)",
      width: "500px",
      height: "350px",
      backgroundColor: "#eeeeee",
    },
  };

  const closeModal = () => {
    setModalIsOpen(false);
    onClose();
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    Swal.fire({
      title: "회원가입",
      text: "회원가입 하시겠습니까?",
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "확인",
      cancelButtonText: "취소",
    }).then((res) => {
      if (res.isConfirmed) {
        const data = { email, password };
        fetch(`${process.env.REACT_APP_BASE_URL}auth/signup`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        })
          .then((res) => res.json())
          .then((res) => {
            console.log(res);
            Swal.fire(
              "가입성공",
              "회원가입에 성공하셨습니다. 해당 정보로 로그인해주세요.",
              "success"
            );
            closeModal();
          })
          .catch((error) => {
            Swal.fire(
              "가입실패",
              "회원가입에 실패하셨습니다. 다시 회원가입해주세요.",
              "error"
            );
            console.log(error);
          });
      }
    });
  };
  // 추가로 validation 적용하기
  const onChangeEmail = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    const emailRegex = /@/;
    if (emailRegex.test(e.target.value)) {
      setIsEmailValid(true);
    } else {
      setIsEmailValid(false);
    }
  };

  const onChangePassword = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
    if (e.target.value.length >= 8) {
      setIsPasswordValid(true);
    } else {
      setIsPasswordValid(false);
    }
  };

  console.log(email, password);
  return (
    <ReactModal
      isOpen={modalIsOpen}
      onRequestClose={closeModal}
      style={modalStyle}
    >
      <form onSubmit={onSubmit}>
        <input type="text" onChange={onChangeEmail} />
        <input type="text" onChange={onChangePassword} />
        {isPasswordValid && isEmailValid && <button>Singup</button>}
      </form>
    </ReactModal>
  );
}
ReactModal.setAppElement("#root");
export default Signup;
