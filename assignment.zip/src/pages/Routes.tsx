import { Routes as ReactRoutes, Route, Navigate } from "react-router-dom";
import Login from "./Login";
import Signup from "./Signup";
import Todo from "./Todo";

function Routes() {
  const isToken = localStorage.getItem("accessToken");
  return (
    <ReactRoutes>
      <Route
        path="/"
        element={!isToken ? <Login /> : <Navigate replace to="/todo" />}
      />
      {/* <Route path="/signup" element={<Signup />} /> */}
      <Route
        path="/todo"
        element={isToken ? <Todo /> : <Navigate replace to="/" />}
      />
    </ReactRoutes>
  );
}

export default Routes;
