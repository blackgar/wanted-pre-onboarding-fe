import { useState } from "react";
import ReactModal from "react-modal";

interface IModal {
  open: boolean;
  onClose: Function;
}

function Signup({ open, onClose }: IModal) {
  const [modalIsOpen, setModalIsOpen] = useState(open);
  const [email, setEmail] = useState("");
  const [isEmailValid, setIsEmailValid] = useState(false);
  const [password, setPassword] = useState("");
  const [isPasswordValid, setIsPasswordValid] = useState(false);

  const modalStyle = {
    content: {
      top: "50%",
      left: "50%",
      right: "auto",
      bottom: "auto",
      marginRight: "-50%",
      transform: "translate(-50%, -50%)",
      width: "500px",
      height: "350px",
      backgroundColor: "#eeeeee",
    },
  };

  const closeModal = () => {
    setModalIsOpen(false);
    onClose();
  };

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = { email, password };
    console.log(data);
    console.log(`${process.env.REACT_APP_BASE_URL}auth/signup`);
    fetch(`${process.env.REACT_APP_BASE_URL}auth/signup`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    })
      .then((res) => res.json())
      .then((res) => console.log(res))
      .catch((error) => console.log(error));
  };
  // 추가로 validation 적용하기
  const onChangeEmail = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
    const emailRegex = /@/;
    if (emailRegex.test(e.target.value)) {
      setIsEmailValid(true);
    } else {
      setIsEmailValid(false);
    }
  };

  const onChangePassword = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPassword(e.target.value);
    if (e.target.value.length >= 8) {
      setIsPasswordValid(true);
    } else {
      setIsPasswordValid(false);
    }
  };

  console.log(email, password);
  return (
    <ReactModal
      isOpen={modalIsOpen}
      onRequestClose={closeModal}
      style={modalStyle}
    >
      <form onSubmit={onSubmit}>
        <input type="text" onChange={onChangeEmail} />
        <input type="text" onChange={onChangePassword} />
        {isPasswordValid && isEmailValid && <button>Singup</button>}
      </form>
    </ReactModal>
  );
}
ReactModal.setAppElement("#root");
export default Signup;
